
#pragma once 

#include <Nave/Nave.h>
#include <Nave/NFException.h>
#include <Nave/NFLog.h>

#include <Nave2D/Nave2D.h>
#include <Nave2D/UIWindowDX9.h>
#include <Nave2D/NFText.h>

#include "TestApp.h"

using namespace Nave;

extern CTestApp* g_pApp;

