#include "Global.h"

CTestUI*	g_pMainWnd = NULL;