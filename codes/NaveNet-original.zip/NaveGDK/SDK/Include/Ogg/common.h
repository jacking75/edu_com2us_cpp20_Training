#ifndef COMMON_HEADER
#define COMMON_HEADER


#define MAX(a,b)	( (a) > (b) ? (a) : (b))
#define MIN(a,b)	( (a) < (b) ? (a) : (b))
#define ABS(x)		( ((x) > 0) ? (x) : (-(x)) )

#endif